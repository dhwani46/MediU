package com.example.dell.mediu;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

/**
 * Created by devanshgandhi on 04/11/17.
 */

public class Account extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }


    public void profile(View view) {
        Intent intent = new Intent(this, Profile.class);
        startActivity(intent);    }

    public void Change_password(View view) {
        Intent intent = new Intent(this, Password.class);
        startActivity(intent);    }

}
