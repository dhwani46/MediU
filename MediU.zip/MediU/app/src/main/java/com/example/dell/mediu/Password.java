package com.example.dell.mediu;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by devanshgandhi on 04/11/17.
 */

public class Password extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }
}
